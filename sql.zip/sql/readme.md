## SQL folder containing all raw data

### tb_unique_bad_smell-schema
This table contains only the database schema for the table we store ChatGPT's responses.

### tb_unique_bad_smell-all-data
This table contains all the data that we queried to ChatGPT. 

### tb_unique_source_code-schema
This table contains only the database schema for the table we use to import all the data from the original dataset.

### tb_unique_source_code-all-data
This table contains all the data we imported from the original dataset to be submitted to ChatGPT.

**File**: `raw_data_all_data`

### Table Fields Description

* **`id_source_code`** - integer identifier when we imported the original dataset to our database.
* **`chat_gpt_response`** - the response ChatGPT gave to our prompts. 
* **`question`** - This columns consists of all prompts we submitted to ChatGPT. For each question, it contains the prompt under evaluation and the source code to be evaluated.
* **`badsmell_base`** - code smells assigned in the original dataset. 
* **`bad_smell_gpt`** - code smells identified by the ChatGPT. These smells were extracted from `chat_gpt_response`.
* **`found_any`** - a boolean field indicating if any of the smells found by ChatGPT are in the dataset. In other words, if ChatGPT answered yes, finding any smell (even if it is not in the original dataset).
* **`valid_bad_smell`** - text field containing the smells in the original dataset that were identified by the ChatGPT.
* **`bad_smell_in_base`** - boolean field indicating if the smells found by ChatGPT are in the original dataset.
* **`bad_smell_not_in_the_base`** - text field containing the smells that ChatGPT found and they are not in the dataset. 
* **`bad_smell_not_found`** - text field containg the smells that are in the dataset but were not detected by ChatGPT.
* **`index`** - the index from the original dataset. Value provided by GitHub that were stored in the original dataset.
* **`index_base`** - the index from the original dataset. Value provided by GitHub that were stored in the original dataset.
* **`url_github`** - the GitHub URL of the source code extracted from the original dataset. 
* **`id_base`** - id field in the original dataset.
* **`nr_question`** - integer field containing 1 or 2, identifying the prompt we submitted to ChatGPT. 
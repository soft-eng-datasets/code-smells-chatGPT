## Raw Data - contains all the data of our database

**File**: `raw_data_all_data`

### Table Fields Description

1. **id:** auto increment identification used for internal purposes (i.e.:** internal foreign keys) 
2. **chat_gpt_response:** the response ChatGPT gave to our prompts. 
3. **question:** This columns consists of all prompts we submitted to ChatGPT. For each question, it contains the prompt under evaluation and the source code to be evaluated. 
4. **badsmell_base:** code smells assigned in the original dataset. 
5. **bad_smell_gpt:** code smells identified by the ChatGPT. These smells were extracted from `chat_gpt_response`.
6. **found_any:** a boolean field indicating if any of the smells found by ChatGPT are in the dataset. In other words, if ChatGPT answered yes, finding any smell (even if it is not in the original dataset).
7. **valid_bad_smell:** text field containing the smells in the original dataset that were identified by the ChatGPT.
8. **bad_smell_in_base:** boolean field indicating if the smells found by ChatGPT are in the original dataset.
9. **bad_smell_not_in_the_base:** text field containing the smells that ChatGPT found and they are not in the dataset. 
10. **bad_smell_not_found:** text field containg the smells that are in the dataset but were not detected by ChatGPT.
11. **index:** the index from the original dataset. Value provided by GitHub that were stored in the original dataset.
12. **index_base:** the index from the original dataset. Value provided by GitHub that were stored in the original dataset.
13. **url_github:** the GitHub URL of the source code extracted from the original dataset. 
14. **nr_question:** integer field containing 1 or 2, identifying the prompt we submitted to ChatGPT.
15. **id_source_code:** the integer identifier when we imported the dataset to our database.
16. **id_base:** id field in the original dataset.
17. **severity:** text field containing the severity of the bad smell from the original dataset (such as critical, minor or major).

